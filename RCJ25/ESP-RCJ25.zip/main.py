from machine import Pin, SoftI2C, I2C
from time import sleep_ms
from math import atan2, sqrt
import time
from ssd1306 import SSD1306_I2C


def signedIntFromBytes(x, endian="big"):
    y = int.from_bytes(x, endian)
    if y >= 0x8000:
        return -((65535 - y) + 1)
    return y

class mpu6050:
    def __init__(self, addr=0x68):
        # Initialize VARs:

        self._GRAVITIY_MS2 = 9.80665
        self._ACC_SCLR_2G = 16384.0
        self._ACC_SCLR_4G = 8192.0
        self._ACC_SCLR_8G = 4096.0
        self._ACC_SCLR_16G = 2048.0
        self._GYR_SCLR_250DEG = 131.0
        self._GYR_SCLR_500DEG = 65.5
        self._GYR_SCLR_1000DEG = 32.8
        self._GYR_SCLR_2000DEG = 16.4
        self._ACC_RNG_2G = 0x00
        self._ACC_RNG_4G = 0x08
        self._ACC_RNG_8G = 0x10
        self._ACC_RNG_16G = 0x18
        self._GYR_RNG_250DEG = 0x00
        self._GYR_RNG_500DEG = 0x08
        self._GYR_RNG_1000DEG = 0x10
        self._GYR_RNG_2000DEG = 0x18
        self._PWR_MGMT_1 = 0x6B
        self._ACCEL_XOUT0 = 0x3B
        self._TEMP_OUT0 = 0x41
        self._GYRO_XOUT0 = 0x43
        self._ACCEL_CONFIG = 0x1C
        self._GYRO_CONFIG = 0x1B
        self._maxFails = 3
        self._MPU6050_ADDRESS = addr

        # Initialize IIC:

        self.i2c = SoftI2C(scl=Pin(22), sda=Pin(21), freq=100000)
        self.addr = self._MPU6050_ADDRESS

        self.i2c.writeto_mem(self.addr, self._PWR_MGMT_1, bytes([0x00]))  # Wake up MPU6050
        sleep_ms(5)

        self._accel_range = self.get_accel_range(True)
        self._gyro_range = self.get_gyro_range(True)

        self.accel_scale = {
            self._ACC_RNG_2G: self._ACC_SCLR_2G,
            self._ACC_RNG_4G: self._ACC_SCLR_4G,
            self._ACC_RNG_8G: self._ACC_SCLR_8G,
            self._ACC_RNG_16G: self._ACC_SCLR_16G
        }.get(self._accel_range, self._ACC_SCLR_2G)

        self.gyro_scale = {
            self._GYR_RNG_250DEG: self._GYR_SCLR_250DEG,
            self._GYR_RNG_500DEG: self._GYR_SCLR_500DEG,
            self._GYR_RNG_1000DEG: self._GYR_SCLR_1000DEG,
            self._GYR_RNG_2000DEG: self._GYR_SCLR_2000DEG
        }.get(self._gyro_range, self._GYR_SCLR_250DEG)

    def readData(self, register):
        failCount = 0
        while failCount < self._maxFails:
            try:
                sleep_ms(10)
                data = self.i2c.readfrom_mem(self.addr, register, 6)
                break
            except:
                failCount += 1
                if failCount >= self._maxFails:
                    return {"x": float("NaN"), "y": float("NaN"), "z": float("NaN")}
        x = signedIntFromBytes(data[0:2])
        y = signedIntFromBytes(data[2:4])
        z = signedIntFromBytes(data[4:6])
        return {"x": x, "y": y, "z": z}

    def read_accel_data(self, g=False):
        accel_data = self.readData(self._ACCEL_XOUT0)
        x = accel_data["x"] / self.accel_scale
        y = accel_data["y"] / self.accel_scale
        z = accel_data["z"] / self.accel_scale
        if not g:
            x *= self._GRAVITIY_MS2
            y *= self._GRAVITIY_MS2
            z *= self._GRAVITIY_MS2
        return {"x": x, "y": y, "z": z}

    def read_gyro_data(self):
        gyro_data = self.readData(self._GYRO_XOUT0)
        x = gyro_data["x"] / self.gyro_scale
        y = gyro_data["y"] / self.gyro_scale
        z = gyro_data["z"] / self.gyro_scale
        return {"x": x, "y": y, "z": z}

    def getYaw(self):
        gyro = self.read_gyro_data()
        return gyro["z"]
        # return 10

    def getRoll(self):
        accel = self.read_accel_data()
        return atan2(accel["y"], accel["z"])

    def getPitch(self):
        accel = self.read_accel_data()
        return atan2(-accel["x"], sqrt(accel["y"]**2 + accel["z"]**2))

    def get_accel_range(self, raw=False):
        raw_data = self.i2c.readfrom_mem(self.addr, self._ACCEL_CONFIG, 2)
        if raw:
            return raw_data[0]
        return {
            self._ACC_RNG_2G: 2,
            self._ACC_RNG_4G: 4,
            self._ACC_RNG_8G: 8,
            self._ACC_RNG_16G: 16
        }.get(raw_data[0], -1)

    def get_gyro_range(self, raw=False):
        raw_data = self.i2c.readfrom_mem(self.addr, self._GYRO_CONFIG, 2)
        if raw:
            return raw_data[0]
        return {
            self._GYR_RNG_250DEG: 250,
            self._GYR_RNG_500DEG: 500,
            self._GYR_RNG_1000DEG: 1000,
            self._GYR_RNG_2000DEG: 2000
        }.get(raw_data[0], -1)

class motor:
    def __init__(self, Ain, Bin):
        self.Apin = Pin(Ain, Pin.OUT)
        self.Bpin = Pin(Bin, Pin.OUT)

    def set_speed(self, speed):
        if speed < 0:
            self.Apin.value(0) 
            self.Bpin.duty_u16(abs(int(speed * 65535 / 100)))
        else:
            self.Bin.value(0)  
            self.Apin.duty_u16(abs(int(speed * 65535 / 100)))

    def stop(self):
        self.Apin.value(0)
        self.Bpin.value(0)

class RCJ25:
    def __init__(self):
        self.previous_error = 0
        self.integral = 0
        self.last_time = time.time() 
        
        #self.gyro = mpu6050()

        self.oled_width = 128
        self.oled_height = 64
        self.i2c_scl =22
        self.i2c_sda = 21
        self.i2c = I2C(0, scl=Pin(self.i2c_scl), sda=Pin(self.i2c_sda))
        self.oled = SSD1306_I2C(self.oled_width, self.oled_height, self.i2c)
        self.motor1 = motor(32, 33)
        self.motor2 = motor(25, 26)
        self.motor3 = motor(27, 14)
        self.motor4 = motor(12, 13)
        self.oled.show()
        self.oled.text("Hello World!", 0, 0)
        self.oled.text("RCJ25!", 0, 16)
        
    def pid_calc(self, current_value, Kp, Ki, Kd):
        current_time = time.time()
        dt = current_time - self.last_time
        self.last_time = current_time  

        error = self.setpoint - current_value

        self.integral += error * dt

        derivative = (error - self.previous_error) / dt if dt > 0 else 0

        output = Kp * error + Ki * integral + Kd * derivative

        self.previous_error = error

        return output

    def read_gyro(self):
        return self.gyro.read_gyro_data()

    def get_yaw(self):
        gyro = mpu6050()
        return gyro.getYaw()
        # return 10

    def get_pitch(self):
        return self.gyro.getPitch()

    def get_roll(self):
        return self.gyro.getRoll()

    def turnRight(self, speed, setpoint):
        error = setpoint - self.get_yaw()
        self.oled.fill(0)
        self.oled.text(f"Turning RIGHT:", 0, 0)
        self.oled.text(f"Speed {speed}", 0, 16)
        self.oled.text(f"SP = {setpoint}", 0, 32)
        self.oled.text(f"ERROR: {error}", 0, 48)
        print(error, setpoint, self.get_yaw())

    def turnLeft(self, speed, setpoint):
        error = setpoint - self.get_yaw()
        self.oled.fill(0)
        self.oled.text(f"Turning LEF:", 0, 0)
        self.oled.text(f"Speed {speed}", 0, 16)
        self.oled.text(f"SP = {setpoint}", 0, 32)
        self.oled.text(f"ERROR: {error}", 0, 48)

    def turn(self, speed, setpoint):
        self.turnRight(speed, setpoint) if setpoint > 0 else self.turnLeft(speed, setpoint)


    def run(self):
        self.oled.show()
        #gyro = mpu6050()
        #print(gyro.getYaw())
        
        print(self.get_yaw())
        
robot = RCJ25()

while True:
    robot.run()






